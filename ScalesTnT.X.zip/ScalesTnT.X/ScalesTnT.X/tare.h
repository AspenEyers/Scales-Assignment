/* 
 * File:   tare.h
 * Author: Tom
 *
 * Created on 11 October 2018, 2:05 PM
 */

#ifndef TARE_H
#define	TARE_H

void random(void);

#endif


