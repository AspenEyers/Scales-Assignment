#include <stdio.h>
//#include <stepin.h>
#include "count_or_weigh_mode.h"
#include "LCD_head.h"
// @set_mode_count.c
//@Thomas McCabe
// @19 September 2018
//@ file containing a weigh mode working trival output

void test (void){
    
    
    
}