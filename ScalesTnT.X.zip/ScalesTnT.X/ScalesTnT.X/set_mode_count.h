/* 
 * File:   set_mode_count.h
 * Author: Aspen
 *
 * Created on 4 October 2018, 2:14 PM
 */

#ifndef SET_MODE_COUNT_H
#define	SET_MODE_COUNT_H

#ifdef	__cplusplus
extern "C" {
#endif

int set_mode_count(int x);
void count_working(void);


#ifdef	__cplusplus
}
#endif

#endif	/* SET_MODE_COUNT_H */

