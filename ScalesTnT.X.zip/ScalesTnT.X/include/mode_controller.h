// This is a basic header file for the step in .h
#ifndef MODE_CONTROLLER_H_ /* Include gard */
#define MODE_CONTROLLER_H_

int user_local(void);
int user_remote(void);
int factory(void);


#endif // SET_MODE_COUNT_H_
