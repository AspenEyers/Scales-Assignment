// This is a basic header file for the step in .h
#ifndef STEP_IN_H_ /* Include gard */
#define STEP_IN_H_

int stepin(int x);

#endif // SET_MODE_COUNT_H_
