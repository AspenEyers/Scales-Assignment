// This is a basic header file for the set_mode_count
#ifndef SET_MODE_COUNT_H_ /* Include gard */
#define SET_MODE_COUNT_H_

int set_mode_count(int x);
void count_working(void);

#endif // SET_MODE_COUNT_H_
