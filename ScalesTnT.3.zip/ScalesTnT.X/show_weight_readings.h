/* 
 * File:   SHOW_WEIGHT_READINGS.h
 * Author: Tom
 *
 * Created on 11 October 2018, 2:19 PM
 */

#ifndef SHOW_WEIGHT_READINGS_H
#define	SHOW_WEIGHT_READINGS_H

void show_weight_seiral(int);
char show_weight_lcd(char*);

#endif





