// @tare.c
//@Thomas McCabe
// @11 October 2018
//@ file containing a tare with working trival output

#include <stdio.h>



void random(void){
    
    // We want to show that Tare is working correctly
   // printf("Tare.c is working\n");
    
}

