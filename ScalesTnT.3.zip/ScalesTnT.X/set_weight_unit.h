#ifndef set_weight_unit_H_   /* Include guard */
#define set_weight_unit_H_

void set_weight_grams (void);
void set_weight_ounces(void);

#endif // set_weight_unit_H_

