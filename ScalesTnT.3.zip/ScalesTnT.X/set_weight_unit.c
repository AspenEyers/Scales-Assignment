// Purpose:
//         cause the instrument to calculate the weight in different units

// @set_weight_unit.c
//@Thomas McCabe
// @9 October 2018
//@ file containing the set weight mode working

#include <stdio.h>
#include "set_weight_unit.h"


// Setting weight to grams
void set_weight_grams (void) {

 // printf("set_weight_grams\n");
  //weight_mult = 1;
  //string_unit[] = "g";

}


// Setting weight to ounces by using a 1/28 multiplier
void set_weight_ounces(){

//	printf("set_weight_ounces\n");
	//weight_mult = 1/28;
	//string_unit[] = "oz";
	
}