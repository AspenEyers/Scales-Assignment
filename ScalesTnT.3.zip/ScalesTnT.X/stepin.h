/* 
 * File:   stepin.h
 * Author: Aspen
 *
 * Created on 4 October 2018, 2:23 PM
 */

#ifndef STEPIN_H
#define	STEPIN_H

#ifdef	__cplusplus
extern "C" {
#endif


// This is a basic header file for the step in .h
#ifndef STEP_IN_H_ /* Include gard */
#define STEP_IN_H_

int stepin(int x);

#endif // SET_MODE_COUNT_H_


#ifdef	__cplusplus
}
#endif

#endif	/* STEPIN_H */

