/* 
 * File:   UI.h
 * Author: Tom
 *
 * Created on 30 October 2018, 5:12 PM
 */

#ifndef UI_H
#define	UI_H

void UIsetup(void);
void user_interface(void);
void buttonControl(void);

#endif	/* UI_H */

