/* 
 * File:   mode_controller.h
 * Author: Aspen
 *
 * Created on 4 October 2018, 2:14 PM
 */

#ifndef MODE_CONTROLLER_H
#define	MODE_CONTROLLER_H

#ifdef	__cplusplus
extern "C" {
#endif


int user_local(void);
int user_remote(void);
int factory(void);
void functionPicker(int);
void modeSelector(int,int);


#ifdef	__cplusplus
}
#endif

#endif	/* MODE_CONTROLLER_H */

