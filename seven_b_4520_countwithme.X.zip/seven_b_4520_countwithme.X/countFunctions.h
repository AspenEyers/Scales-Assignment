/* 
 * File:   countFunctions.h
 * Author: hulioinspain
 *
 * Created on 24 October 2018, 4:09 PM
 */

#ifndef COUNTFUNCTIONS_H
#define	COUNTFUNCTIONS_H

#ifdef	__cplusplus
extern "C" {
#endif

    void set_count(void);


#ifdef	__cplusplus
}
#endif

#endif	/* COUNTFUNCTIONS_H */

